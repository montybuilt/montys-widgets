# -*- coding: utf-8 -*-
"""
Main Program
"""

from module import divide_numbers

# Caller function

print(divide_numbers(5,0))
