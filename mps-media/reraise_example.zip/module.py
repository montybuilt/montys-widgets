'''
Module code
'''

def divide_numbers(a, b):
    
    try:
        
        result = a / b
    
    except Exception as ex:
        
        # Log the error details to the log.txt file
        with open("log.txt", "a") as log_file:
            log_file.write(f"Error: {ex} with inputs a={a}, b={b}\n")
    
    else:
        
        return result

if __name__ == "__main__":
    print(divide_numbers(5,8))




