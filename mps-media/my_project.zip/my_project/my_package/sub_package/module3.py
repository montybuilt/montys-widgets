# module3.py

def func3():
    return f"func3, {__file__}, {__name__}"


if __name__ == "__main__":
    print(func3())