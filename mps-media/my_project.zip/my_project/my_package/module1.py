# module1.py

def func1():
    return f"func1, {__file__}, {__name__}"


if __name__ == "__main__":
    print(func1())