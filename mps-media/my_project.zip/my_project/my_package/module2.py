# module2.py

def func2():
    return f"func2, {__file__}, {__name__}"


if __name__ == "__main__":
    print(func2())

